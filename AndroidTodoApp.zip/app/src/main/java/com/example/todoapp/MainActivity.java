package com.example.todoapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements TaskAdapter.OnTaskClickListener {

    private RecyclerView recyclerView;
    private TaskAdapter adapter;
    private ArrayList<Task> taskList;
    private ImageButton btnAddTask;

    private static final String PREFS_NAME = "todo_prefs";
    private static final String KEY_TASKS = "tasks";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerViewTasks);
        btnAddTask = findViewById(R.id.btnAddTask);

        taskList = new ArrayList<>();
        loadTasksFromStorage();

        adapter = new TaskAdapter(this, taskList, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        btnAddTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTaskDialog(-1);
            }
        });
    }

    private void showTaskDialog(int positionToEdit) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(positionToEdit == -1 ? "Add Task" : "Edit Task");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        if (positionToEdit != -1) {
            input.setText(taskList.get(positionToEdit).getTitle());
            input.setSelection(input.getText().length());
        }
        builder.setView(input);

        builder.setPositiveButton(positionToEdit == -1 ? "Add" : "Update", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String taskTitle = input.getText().toString().trim();
                if (taskTitle.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Task title cannot be empty", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (positionToEdit == -1) {
                    taskList.add(new Task(taskTitle));
                    Toast.makeText(MainActivity.this, "Task added", Toast.LENGTH_SHORT).show();
                } else {
                    taskList.get(positionToEdit).setTitle(taskTitle);
                    Toast.makeText(MainActivity.this, "Task updated", Toast.LENGTH_SHORT).show();
                }
                adapter.notifyDataSetChanged();
                saveTasksToStorage();
            }
        });

        builder.setNegativeButton("Cancel", null);

        builder.show();
    }

    @Override
    public void onEditClick(int position) {
        showTaskDialog(position);
    }

    @Override
    public void onDeleteClick(int position) {
        Task task = taskList.get(position);
        new AlertDialog.Builder(this)
                .setTitle("Delete Task")
                .setMessage("Are you sure you want to delete this task?

" + task.getTitle())
                .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        taskList.remove(position);
                        adapter.notifyItemRemoved(position);
                        saveTasksToStorage();
                        Toast.makeText(MainActivity.this, "Task deleted", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void saveTasksToStorage() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        JSONArray jsonArray = new JSONArray();
        for (Task task : taskList) {
            jsonArray.put(task.getTitle());
        }
        editor.putString(KEY_TASKS, jsonArray.toString());
        editor.apply();
    }

    private void loadTasksFromStorage() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String tasksJson = prefs.getString(KEY_TASKS, null);
        taskList.clear();

        if (tasksJson != null) {
            try {
                JSONArray jsonArray = new JSONArray(tasksJson);
                for (int i = 0; i < jsonArray.length(); i++) {
                    String title = jsonArray.getString(i);
                    taskList.add(new Task(title));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
